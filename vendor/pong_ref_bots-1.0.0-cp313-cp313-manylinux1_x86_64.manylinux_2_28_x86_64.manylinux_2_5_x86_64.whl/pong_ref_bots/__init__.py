"""Bots de referencia Medium y Hard de la Práctica Pong (§11).

El paquete se distribuye solo como rueda compilada: ``_bots`` es una extensión
de Cython y su código fuente no se incluye.
"""

from ._bots import Hard, Medium

__all__ = ["Hard", "Medium"]
__version__ = "1.0.0"
